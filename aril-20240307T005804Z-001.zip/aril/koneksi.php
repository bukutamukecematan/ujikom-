<?php 
$koneksi= new mysqli ("localhost","root","","i-login") or die ("error");
?>